<div class="space-y-6">
  <div class="bg-white rounded-2xl shadow-sm border border-gray-200">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between px-6 py-5 border-b border-gray-200">
      <div>
        <h1 class="text-2xl font-semibold text-gray-800">Eğitim Yönetimi</h1>
        <p class="text-sm text-gray-500 mt-1">Mevcut eğitimleri listeleyin ve yeni eğitim ekleyin.</p>
      </div>
      <button type="button" onclick="openStudyModal()"
        class="px-5 py-2 border border-blue-200 text-blue-600 rounded-lg hover:bg-blue-50 transition flex items-center justify-center gap-2">
        <i class="fas fa-plus-circle"></i>
        <span>Yeni Eğitim</span>
      </button>
    </div>

    <div class="overflow-x-auto">
      <table class="w-full">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr>
            <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-12"></th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Eğitim</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden lg:table-cell">
              Açıklama</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden md:table-cell">
              Slug</th>
            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-24">Foto</th>
            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-20">İşlem</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200" id="sortable-table" data-entity="studies">
          <?php if(isset($studies) && !empty($studies)): ?>
          <?php foreach($studies as $study): ?>
          <?php
            $adminBaseUrl = rtrim(base_url(), '/');
            $publicBaseUrl = $adminBaseUrl;
            if (substr($adminBaseUrl, -6) === '/admin') {
              $publicBaseUrl = substr($adminBaseUrl, 0, -6);
            }
            $publicBaseUrl = rtrim($publicBaseUrl, '/') . '/';
            $photoValue = ltrim((string) ($study['photo'] ?? ''), '/');
            if ($photoValue !== '' && strpos($photoValue, '/') === false) {
              $projectRoot = dirname(ROOTPATH);
              $rootPhotoPath = $projectRoot . '/upload/images/' . $photoValue;
              if (is_file($rootPhotoPath)) {
                $photoUrl = $publicBaseUrl . 'upload/images/' . $photoValue;
              } else {
                $photoUrl = $adminBaseUrl . '/uploads/studies/' . $photoValue;
              }
            } elseif ($photoValue !== '') {
              if (strpos($photoValue, 'upload/') === 0) {
                $photoUrl = $publicBaseUrl . $photoValue;
              } else {
                $photoUrl = $adminBaseUrl . '/' . $photoValue;
              }
            } else {
              $photoUrl = 'https://via.placeholder.com/80?text=Egitim';
            }
          ?>
          <tr class="hover:bg-gray-50 transition sortable-row" data-id="<?= (int) $study['id'] ?>">
            <td class="px-4 py-4">
              <div class="flex items-center justify-center cursor-move drag-handle text-gray-400 hover:text-gray-600">
                <i class="fas fa-grip-vertical"></i>
              </div>
            </td>
            <td class="px-6 py-4 text-sm font-medium text-gray-900">
              <?= esc($study['name'] ?? '') ?>
            </td>
            <td class="px-6 py-4 hidden lg:table-cell">
              <p class="text-sm text-gray-600 max-w-xs truncate"><?= esc($study['description'] ?? '') ?></p>
            </td>
            <td class="px-6 py-4 hidden md:table-cell">
              <span class="text-xs text-gray-600"><?= esc($study['slug'] ?? '') ?></span>
            </td>
            <td class="px-6 py-4">
              <div class="flex items-center justify-center">
                <img src="<?= esc($photoUrl) ?>" alt="<?= esc($study['name'] ?? 'Eğitim') ?>"
                  class="w-12 h-12 rounded-lg object-cover">
              </div>
            </td>
            <td class="px-6 py-4">
              <div class="flex items-center justify-center space-x-3">
                <button onclick="openStudyModal(<?= (int) $study['id'] ?>)"
                  class="text-blue-600 hover:text-blue-800 transition" title="Düzenle">
                  <i class="fas fa-edit"></i>
                </button>
                <button onclick="deleteStudy(<?= (int) $study['id'] ?>)"
                  class="text-red-600 hover:text-red-800 transition" title="Sil">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php else: ?>
          <tr>
            <td colspan="6" class="px-6 py-8 text-center">
              <i class="fas fa-graduation-cap text-gray-300 text-4xl mb-3"></i>
              <p class="text-gray-500">Henüz eğitim bulunmuyor</p>
            </td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php echo view('admin/studies/modal'); ?>
<?php echo view('admin/studies/scripts'); ?>
