<script>
const studiesBaseUrl = '<?= rtrim(base_url(), '/') ?>' + '/';
const studyModal = document.getElementById('studyModal');
const studyModalTitle = document.getElementById('studyModalTitle');
const studyIdField = document.getElementById('studyId');
const studyNameInput = document.getElementById('studyName');
const studySlugInput = document.getElementById('studySlug');
const studyDescriptionInput = document.getElementById('studyDescription');
const studyPhotoInput = document.getElementById('studyPhoto');
const maxStudyPhotoSize = 4 * 1024 * 1024;

let slugTouched = false;
let currentStudyId = null;

function openStudyModal(id = null) {
  currentStudyId = id;
  resetStudyForm();
  if (studyModalTitle) {
    studyModalTitle.textContent = id ? 'Eğitim Düzenle' : 'Eğitim Ekle';
  }
  if (studyModal) {
    studyModal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }

  if (id) {
    loadStudyData(id);
  }
}

function closeStudyModal() {
  if (studyModal) {
    studyModal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
  currentStudyId = null;
}

studyModal?.addEventListener('click', function(event) {
  if (event.target === this) {
    closeStudyModal();
  }
});

document.addEventListener('keydown', function(event) {
  if (event.key === 'Escape' && !studyModal?.classList.contains('hidden')) {
    closeStudyModal();
  }
});

studySlugInput?.addEventListener('input', function() {
  slugTouched = (this.value || '').trim().length > 0;
});

studyNameInput?.addEventListener('input', function() {
  if (!slugTouched && studySlugInput) {
    studySlugInput.value = slugify(this.value || '');
  }
});

studyPhotoInput?.addEventListener('change', function() {
  const file = this.files?.[0];
  if (file && file.size > maxStudyPhotoSize) {
    alert('Fotoğraf boyutu en fazla 4MB olmalıdır.');
    this.value = '';
  }
});

function slugify(value) {
  const map = {
    ç: 'c',
    ğ: 'g',
    ı: 'i',
    ö: 'o',
    ş: 's',
    ü: 'u',
    Ç: 'c',
    Ğ: 'g',
    İ: 'i',
    Ö: 'o',
    Ş: 's',
    Ü: 'u',
  };

  return String(value || '')
    .replace(/[çğıöşüÇĞİÖŞÜ]/g, match => map[match] || match)
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .trim()
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function resetStudyForm() {
  if (studyIdField) studyIdField.value = '';
  if (studyNameInput) studyNameInput.value = '';
  if (studySlugInput) studySlugInput.value = '';
  if (studyDescriptionInput) studyDescriptionInput.value = '';
  if (studyPhotoInput) studyPhotoInput.value = '';
  slugTouched = false;
}

function saveStudy() {
  const formData = new FormData();
  formData.append('name', studyNameInput?.value ?? '');
  formData.append('slug', studySlugInput?.value ?? '');
  formData.append('description', studyDescriptionInput?.value ?? '');

  if (studyPhotoInput?.files?.length) {
    formData.append('photo', studyPhotoInput.files[0]);
  }

  const url = currentStudyId ? `${studiesBaseUrl}studies/${currentStudyId}` : `${studiesBaseUrl}studies`;

  fetch(url, {
      method: 'POST',
      body: formData,
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    })
    .then(response => response.json().then(data => ({
      ok: response.ok,
      data
    })))
    .then(result => {
      if (result.ok && result.data?.success) {
        closeStudyModal();
        window.location.reload();
        return;
      }
      handleStudyErrors(result.data || {});
    })
    .catch(() => alert('Eğitim kaydedilemedi.'));
}

function loadStudyData(id) {
  fetch(`${studiesBaseUrl}studies/${id}`, {
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        fillStudyForm(data.data);
      } else {
        alert(data.message || 'Eğitim yüklenemedi.');
      }
    })
    .catch(() => alert('Eğitim yüklenemedi.'));
}

function fillStudyForm(study) {
  if (studyIdField) studyIdField.value = study.id ?? '';
  if (studyNameInput) studyNameInput.value = study.name ?? '';
  if (studySlugInput) studySlugInput.value = study.slug ?? '';
  if (studyDescriptionInput) studyDescriptionInput.value = study.description ?? '';
  slugTouched = !!(studySlugInput?.value || '').trim();
}

function handleStudyErrors(data) {
  if (data.errors) {
    const messages = Object.values(data.errors).join('\n');
    alert(messages);
  } else if (data.message) {
    alert(data.message);
  } else {
    alert('Form doğrulanamadı.');
  }
}

function deleteStudy(id) {
  if (!confirm('Bu eğitimi silmek istediğinizden emin misiniz?')) {
    return;
  }

  fetch(`${studiesBaseUrl}studies/${id}`, {
      method: 'DELETE',
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        window.location.reload();
      } else {
        alert(data.message || 'Eğitim silinemedi.');
      }
    })
    .catch(() => alert('Eğitim silinemedi.'));
}
</script>
