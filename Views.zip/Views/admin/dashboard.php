<!-- Dashboard Content -->
<div>
  <!-- Welcome Section -->
  <div class="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white mb-6">
    <h1 class="text-2xl md:text-3xl font-bold mb-2">Hoş Geldiniz, <?= service('auth')->username ?? 'Admin' ?>!</h1>
    <p class="text-blue-100">Deniz Web Ajans Yönetim Paneline hoş geldiniz. İşte bugünün özeti.</p>
  </div>

  <!-- Stats Grid -->
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-6">
    <!-- Stat Card 1 -->
    <div class="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
      <div class="flex items-center justify-between mb-4">
        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
          <i class="fas fa-graduation-cap text-blue-600 text-xl"></i>
        </div>
        <span class="text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded">+12%</span>
      </div>
      <h3 class="text-2xl font-bold text-gray-800 mb-1"><?= $stats['egitimler'] ?? 0 ?></h3>
      <p class="text-gray-600 text-sm">Toplam Eğitimler</p>
    </div>

    <!-- Stat Card 2 -->
    <div class="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
      <div class="flex items-center justify-between mb-4">
        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
          <i class="fas fa-user-doctor text-purple-600 text-xl"></i>
        </div>
        <span class="text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded">+8%</span>
      </div>
      <h3 class="text-2xl font-bold text-gray-800 mb-1"><?= $stats['doktorlar'] ?? 0 ?></h3>
      <p class="text-gray-600 text-sm">Toplam Doktorlar</p>
    </div>

    <!-- Stat Card 3 -->
    <div class="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
      <div class="flex items-center justify-between mb-4">
        <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
          <i class="fas fa-blog text-orange-600 text-xl"></i>
        </div>
        <span class="text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded">+15%</span>
      </div>
      <h3 class="text-2xl font-bold text-gray-800 mb-1"><?= $stats['blog'] ?? 0 ?></h3>
      <p class="text-gray-600 text-sm">Blog Yazısı</p>
    </div>

  </div>

  <div class="mb-6">
    <!-- Quick Actions -->
    <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
      <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-800">Hızlı İşlemler</h3>
      </div>
      <div class="p-6">
        <div class="grid grid-cols-2 gap-4">
          <a href="<?= base_url('doctors') ?>"
            class="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition group">
            <i class="fas fa-plus-circle text-3xl text-gray-400 group-hover:text-purple-500 mb-2"></i>
            <span class="text-sm font-medium text-gray-700 group-hover:text-purple-600">Yeni Doktor</span>
          </a>

          <a href="<?= base_url('studies') ?>"
            class="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition group">
            <i class="fas fa-plus-circle text-3xl text-gray-400 group-hover:text-blue-500 mb-2"></i>
            <span class="text-sm font-medium text-gray-700 group-hover:text-blue-600">Yeni Eğitim</span>
          </a>

          <a href="<?= base_url('blog/create') ?>"
            class="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-orange-500 hover:bg-orange-50 transition group">
            <i class="fas fa-plus-circle text-3xl text-gray-400 group-hover:text-orange-500 mb-2"></i>
            <span class="text-sm font-medium text-gray-700 group-hover:text-orange-600">Yeni Blog Yazısı</span>
          </a>
        </div>
      </div>
    </div>
  </div>

  </div>
