<div id="doctorModal" class="fixed inset-0 bg-black bg-opacity-50 z-[9999] hidden flex items-center justify-center p-4">
  <div class="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
    <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
      <h2 id="doctorModalTitle" class="text-xl font-semibold text-gray-800">Doktor Ekle</h2>
      <div class="flex items-center space-x-2">
        <button onclick="closeDoctorModal()" class="px-4 py-2 text-gray-600 hover:text-gray-800 font-medium transition">
          İptal
        </button>
        <button onclick="saveDoctor()"
          class="px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition flex items-center space-x-2">
          <span>Kaydet</span>
          <i class="fas fa-plus"></i>
        </button>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto p-6">
      <input type="hidden" id="doctorId">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Ad</label>
          <input id="doctorName" type="text" placeholder="Ad"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Soyad</label>
          <input id="doctorSurname" type="text" placeholder="Soyad"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Uzmanlık</label>
          <input id="doctorSpecialty" type="text" placeholder="Nöroloji"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Doğum Tarihi</label>
          <input id="doctorBirthdate" type="date"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Deneyim</label>
          <input id="doctorExperience" type="text" placeholder="10 yıl"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Slug</label>
          <input id="doctorSlug" type="text" placeholder="doktor-slug"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div class="md:col-span-2">
          <label class="block text-sm font-medium text-gray-700 mb-2">Biyografi</label>
          <textarea id="doctorBiography" rows="4" placeholder="Kısa biyografi"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition resize-none"></textarea>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Telefon</label>
          <input id="doctorPhone" type="text" placeholder="+90..."
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">E-posta</label>
          <input id="doctorEmail" type="email" placeholder="ornek@mail.com"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Website</label>
          <input id="doctorWebsite" type="url" placeholder="https://"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Fotoğraf (Maks. 4MB)</label>
          <input id="doctorPhoto" type="file" accept="image/*"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Facebook</label>
          <input id="doctorFacebook" type="url" placeholder="https://facebook.com/"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Twitter</label>
          <input id="doctorTwitter" type="url" placeholder="https://twitter.com/"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Instagram</label>
          <input id="doctorInstagram" type="url" placeholder="https://instagram.com/"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">LinkedIn</label>
          <input id="doctorLinkedin" type="url" placeholder="https://linkedin.com/"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">YouTube</label>
          <input id="doctorYoutube" type="url" placeholder="https://youtube.com/"
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">WhatsApp</label>
          <input id="doctorWhatsapp" type="text" placeholder="+90..."
            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition">
        </div>
      </div>
    </div>
  </div>
</div>
