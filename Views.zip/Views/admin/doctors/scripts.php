<script>
const doctorsBaseUrl = '<?= rtrim(base_url(), '/') ?>' + '/';
const doctorModal = document.getElementById('doctorModal');
const doctorModalTitle = document.getElementById('doctorModalTitle');
const doctorIdField = document.getElementById('doctorId');
const doctorNameInput = document.getElementById('doctorName');
const doctorSurnameInput = document.getElementById('doctorSurname');
const doctorSpecialtyInput = document.getElementById('doctorSpecialty');
const doctorBirthdateInput = document.getElementById('doctorBirthdate');
const doctorExperienceInput = document.getElementById('doctorExperience');
const doctorSlugInput = document.getElementById('doctorSlug');
const doctorBiographyInput = document.getElementById('doctorBiography');
const doctorPhoneInput = document.getElementById('doctorPhone');
const doctorEmailInput = document.getElementById('doctorEmail');
const doctorWebsiteInput = document.getElementById('doctorWebsite');
const doctorPhotoInput = document.getElementById('doctorPhoto');
const doctorFacebookInput = document.getElementById('doctorFacebook');
const doctorTwitterInput = document.getElementById('doctorTwitter');
const doctorInstagramInput = document.getElementById('doctorInstagram');
const doctorLinkedinInput = document.getElementById('doctorLinkedin');
const doctorYoutubeInput = document.getElementById('doctorYoutube');
const doctorWhatsappInput = document.getElementById('doctorWhatsapp');
const maxDoctorPhotoSize = 4 * 1024 * 1024;

let doctorSlugTouched = false;
let currentDoctorId = null;

function openDoctorModal(id = null) {
  currentDoctorId = id;
  resetDoctorForm();
  if (doctorModalTitle) {
    doctorModalTitle.textContent = id ? 'Doktor Düzenle' : 'Doktor Ekle';
  }
  if (doctorModal) {
    doctorModal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }

  if (id) {
    loadDoctorData(id);
  }
}

function closeDoctorModal() {
  if (doctorModal) {
    doctorModal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
  currentDoctorId = null;
}

doctorModal?.addEventListener('click', function(event) {
  if (event.target === this) {
    closeDoctorModal();
  }
});

document.addEventListener('keydown', function(event) {
  if (event.key === 'Escape' && !doctorModal?.classList.contains('hidden')) {
    closeDoctorModal();
  }
});

doctorSlugInput?.addEventListener('input', function() {
  doctorSlugTouched = (this.value || '').trim().length > 0;
});

doctorPhotoInput?.addEventListener('change', function() {
  const file = this.files?. [0];
  if (file && file.size > maxDoctorPhotoSize) {
    alert('Fotoğraf boyutu en fazla 4MB olmalıdır.');
    this.value = '';
  }
});

function updateDoctorSlug() {
  if (!doctorSlugTouched && doctorSlugInput) {
    const fullName = `${doctorNameInput?.value ?? ''} ${doctorSurnameInput?.value ?? ''}`.trim();
    doctorSlugInput.value = slugify(fullName);
  }
}

doctorNameInput?.addEventListener('input', updateDoctorSlug);
doctorSurnameInput?.addEventListener('input', updateDoctorSlug);

function slugify(value) {
  const map = {
    ç: 'c',
    ğ: 'g',
    ı: 'i',
    ö: 'o',
    ş: 's',
    ü: 'u',
    Ç: 'c',
    Ğ: 'g',
    İ: 'i',
    Ö: 'o',
    Ş: 's',
    Ü: 'u',
  };

  return String(value || '')
    .replace(/[çğıöşüÇĞİÖŞÜ]/g, match => map[match] || match)
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .trim()
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function resetDoctorForm() {
  if (doctorIdField) doctorIdField.value = '';
  if (doctorNameInput) doctorNameInput.value = '';
  if (doctorSurnameInput) doctorSurnameInput.value = '';
  if (doctorSpecialtyInput) doctorSpecialtyInput.value = '';
  if (doctorBirthdateInput) doctorBirthdateInput.value = '';
  if (doctorExperienceInput) doctorExperienceInput.value = '';
  if (doctorSlugInput) doctorSlugInput.value = '';
  if (doctorBiographyInput) doctorBiographyInput.value = '';
  if (doctorPhoneInput) doctorPhoneInput.value = '';
  if (doctorEmailInput) doctorEmailInput.value = '';
  if (doctorWebsiteInput) doctorWebsiteInput.value = '';
  if (doctorPhotoInput) doctorPhotoInput.value = '';
  if (doctorFacebookInput) doctorFacebookInput.value = '';
  if (doctorTwitterInput) doctorTwitterInput.value = '';
  if (doctorInstagramInput) doctorInstagramInput.value = '';
  if (doctorLinkedinInput) doctorLinkedinInput.value = '';
  if (doctorYoutubeInput) doctorYoutubeInput.value = '';
  if (doctorWhatsappInput) doctorWhatsappInput.value = '';
  doctorSlugTouched = false;
}

function saveDoctor() {
  const formData = new FormData();
  formData.append('name', doctorNameInput?.value ?? '');
  formData.append('surname', doctorSurnameInput?.value ?? '');
  formData.append('specialty', doctorSpecialtyInput?.value ?? '');
  formData.append('birthdate', doctorBirthdateInput?.value ?? '');
  formData.append('experience_days', doctorExperienceInput?.value ?? '');
  formData.append('slug', doctorSlugInput?.value ?? '');
  formData.append('biography', doctorBiographyInput?.value ?? '');
  formData.append('phone', doctorPhoneInput?.value ?? '');
  formData.append('email', doctorEmailInput?.value ?? '');
  formData.append('website', doctorWebsiteInput?.value ?? '');
  formData.append('facebook', doctorFacebookInput?.value ?? '');
  formData.append('twitter', doctorTwitterInput?.value ?? '');
  formData.append('instagram', doctorInstagramInput?.value ?? '');
  formData.append('linkedin', doctorLinkedinInput?.value ?? '');
  formData.append('youtube', doctorYoutubeInput?.value ?? '');
  formData.append('whatsapp', doctorWhatsappInput?.value ?? '');

  if (doctorPhotoInput?.files?.length) {
    formData.append('photo', doctorPhotoInput.files[0]);
  }

  const url = currentDoctorId ? `${doctorsBaseUrl}doctors/${currentDoctorId}` : `${doctorsBaseUrl}doctors`;

  fetch(url, {
      method: 'POST',
      body: formData,
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    })
    .then(response => response.json().then(data => ({
      ok: response.ok,
      data
    })))
    .then(result => {
      if (result.ok && result.data?.success) {
        closeDoctorModal();
        window.location.reload();
        return;
      }
      handleDoctorErrors(result.data || {});
    })
    .catch(() => alert('Doktor kaydedilemedi.'));
}

function loadDoctorData(id) {
  fetch(`${doctorsBaseUrl}doctors/${id}`, {
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        fillDoctorForm(data.data);
      } else {
        alert(data.message || 'Doktor yüklenemedi.');
      }
    })
    .catch(() => alert('Doktor yüklenemedi.'));
}

function fillDoctorForm(doctor) {
  if (doctorIdField) doctorIdField.value = doctor.id ?? '';
  if (doctorNameInput) doctorNameInput.value = doctor.name ?? '';
  if (doctorSurnameInput) doctorSurnameInput.value = doctor.surname ?? '';
  if (doctorSpecialtyInput) doctorSpecialtyInput.value = doctor.specialty ?? '';
  if (doctorBirthdateInput) doctorBirthdateInput.value = doctor.birthdate ?? '';
  if (doctorExperienceInput) doctorExperienceInput.value = doctor.experience_days ?? '';
  if (doctorSlugInput) doctorSlugInput.value = doctor.slug ?? '';
  if (doctorBiographyInput) doctorBiographyInput.value = doctor.biography ?? '';
  if (doctorPhoneInput) doctorPhoneInput.value = doctor.phone ?? '';
  if (doctorEmailInput) doctorEmailInput.value = doctor.email ?? '';
  if (doctorWebsiteInput) doctorWebsiteInput.value = doctor.website ?? '';
  if (doctorFacebookInput) doctorFacebookInput.value = doctor.facebook ?? '';
  if (doctorTwitterInput) doctorTwitterInput.value = doctor.twitter ?? '';
  if (doctorInstagramInput) doctorInstagramInput.value = doctor.instagram ?? '';
  if (doctorLinkedinInput) doctorLinkedinInput.value = doctor.linkedin ?? '';
  if (doctorYoutubeInput) doctorYoutubeInput.value = doctor.youtube ?? '';
  if (doctorWhatsappInput) doctorWhatsappInput.value = doctor.whatsapp ?? '';
  doctorSlugTouched = !!(doctor.slug || '').trim();
}

function handleDoctorErrors(data) {
  if (data.errors) {
    const messages = Object.values(data.errors).join('\n');
    alert(messages);
  } else if (data.message) {
    alert(data.message);
  } else {
    alert('Form doğrulanamadı.');
  }
}

function deleteDoctor(id) {
  if (!confirm('Bu doktoru silmek istediğinizden emin misiniz?')) {
    return;
  }

  fetch(`${doctorsBaseUrl}doctors/${id}`, {
      method: 'DELETE',
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        window.location.reload();
      } else {
        alert(data.message || 'Doktor silinemedi.');
      }
    })
    .catch(() => alert('Doktor silinemedi.'));
}
</script>