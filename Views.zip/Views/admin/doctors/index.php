<div class="space-y-6">
  <div class="bg-white rounded-2xl shadow-sm border border-gray-200">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between px-6 py-5 border-b border-gray-200">
      <div>
        <h1 class="text-2xl font-semibold text-gray-800">Doktor Yönetimi</h1>
        <p class="text-sm text-gray-500 mt-1">Mevcut doktorları listeleyin ve yeni doktor ekleyin.</p>
      </div>
      <button type="button" onclick="openDoctorModal()"
        class="px-5 py-2 border border-blue-200 text-blue-600 rounded-lg hover:bg-blue-50 transition flex items-center justify-center gap-2">
        <i class="fas fa-plus-circle"></i>
        <span>Yeni Doktor</span>
      </button>
    </div>

    <div class="overflow-x-auto">
      <table class="w-full">
        <thead class="bg-gray-50 border-b border-gray-200">
          <tr>
            <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-12"></th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Doktor</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden md:table-cell">
              Uzmanlık</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden lg:table-cell">
              İletişim</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Slug</th>
            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-24">Foto</th>
            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-20">İşlem</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200" id="sortable-table" data-entity="doctors">
          <?php if(isset($doctors) && !empty($doctors)): ?>
          <?php foreach($doctors as $doctor): ?>
          <?php
            $adminBaseUrl = rtrim(base_url(), '/');
            $publicBaseUrl = $adminBaseUrl;
            if (substr($adminBaseUrl, -6) === '/admin') {
              $publicBaseUrl = substr($adminBaseUrl, 0, -6);
            }
            $publicBaseUrl = rtrim($publicBaseUrl, '/') . '/';
            $photoValue = ltrim((string) ($doctor['photo'] ?? ''), '/');
            if ($photoValue !== '' && strpos($photoValue, '/') === false) {
              $photoUrl = $publicBaseUrl . 'upload/images/' . $photoValue;
            } elseif ($photoValue !== '') {
              $photoUrl = $publicBaseUrl . $photoValue;
            } else {
              $photoUrl = 'https://via.placeholder.com/80?text=Doktor';
            }
            $fullName = trim(($doctor['name'] ?? '') . ' ' . ($doctor['surname'] ?? ''));
          ?>
          <tr class="hover:bg-gray-50 transition sortable-row" data-id="<?= (int) $doctor['id'] ?>">
            <td class="px-4 py-4">
              <div class="flex items-center justify-center cursor-move drag-handle text-gray-400 hover:text-gray-600">
                <i class="fas fa-grip-vertical"></i>
              </div>
            </td>
            <td class="px-6 py-4 text-sm font-medium text-gray-900">
              <?= esc($fullName ?: 'Doktor') ?>
            </td>
            <td class="px-6 py-4 text-sm text-gray-600 hidden md:table-cell">
              <?= esc($doctor['specialty'] ?? '-') ?>
            </td>
            <td class="px-6 py-4 text-sm text-gray-600 hidden lg:table-cell">
              <div class="flex flex-col gap-1">
                <span><?= esc($doctor['phone'] ?? '-') ?></span>
                <span><?= esc($doctor['email'] ?? '-') ?></span>
              </div>
            </td>
            <td class="px-6 py-4">
              <span class="text-xs text-gray-600"><?= esc($doctor['slug'] ?? '') ?></span>
            </td>
            <td class="px-6 py-4">
              <div class="flex items-center justify-center">
                <img src="<?= esc($photoUrl) ?>" alt="<?= esc($fullName ?: 'Doktor') ?>"
                  class="w-12 h-12 rounded-lg object-cover">
              </div>
            </td>
            <td class="px-6 py-4">
              <div class="flex items-center justify-center space-x-3">
                <button onclick="openDoctorModal(<?= (int) $doctor['id'] ?>)"
                  class="text-blue-600 hover:text-blue-800 transition" title="Düzenle">
                  <i class="fas fa-edit"></i>
                </button>
                <button onclick="deleteDoctor(<?= (int) $doctor['id'] ?>)"
                  class="text-red-600 hover:text-red-800 transition" title="Sil">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php else: ?>
          <tr>
            <td colspan="7" class="px-6 py-8 text-center">
              <i class="fas fa-user-doctor text-gray-300 text-4xl mb-3"></i>
              <p class="text-gray-500">Henüz doktor bulunmuyor</p>
            </td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php echo view('admin/doctors/modal'); ?>
<?php echo view('admin/doctors/scripts'); ?>
